
// Основы Swift / Урок 1 / Константы и переменные

var greetings = "Hello, World"

//  greetings = "Hello, Swift"

// direction

var direction = "Left"

var helloHowAreYou = "Fine"

var xx2 = 10

print(greetings)

// direction = "Right"

// var direction = "Left"

// kafkafklf.f;s;f,fs;fs;sfwqqs

/*
 aafsafas
 ;ep[[tiwiq
 zvx,ncklasaz
 */
 

