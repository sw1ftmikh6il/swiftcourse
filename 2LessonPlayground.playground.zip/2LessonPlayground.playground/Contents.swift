
// Основы Swift / Урок 2 / Типы данных

var number: Int = 10

var a = 42.25
var b = 10

var sum2 = a + Double(b)

Int.min
Int.max
//-------
UInt.min
UInt.max

Int8.min
Int8.max
//-------
UInt8.min
UInt8.max

Int16.min
Int16.max
//-------
UInt16.min
UInt16.max

Int32.min
Int32.max
//-------
UInt32.min
UInt32.max

Int64.min
Int64.max
//-------
UInt64.min
UInt64.max


var x = 5.47
var c = -300.145

var float = 1.452324


var greetings = " Hello World! "

var t = " Hello "

var u = " Swift "

var some = t + u


var areYouHappy = true

if areYouHappy {
        print(" Good ")
}   else {
    print(" Bad ")
}




































